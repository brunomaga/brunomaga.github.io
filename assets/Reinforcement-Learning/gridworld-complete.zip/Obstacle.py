
# coding: utf-8

# In[ ]:

get_ipython().magic(u'matplotlib inline')
import numpy as np
execfile('plotting.py')
import pandas as pd

SAVEPLOT=False
if SAVEPLOT:
    sns.set_context("paper",font_scale=1.5)
else: 
    sns.set_context("poster")
    
    
import matplotlib.pylab as plt
import gridworld as gw
gw=reload(gw)

import pickle



# In[ ]:

N_runs=50

np.random.seed(10) # (11) #10
grid=gw.ContinuousWorld(obstacle=True) #,exploration_factor=[1,0.1])

grid.run(N_runs,1)


# In[ ]:

grid.plot_Q()
saveplot('obstacle_Q_Run%i'%N_runs,SAVEPLOT=SAVEPLOT)


grid.plot_neuron_arrows(visualize=True)
saveplot('obstacle_neuron_arrows_Run%i'%N_runs,SAVEPLOT=SAVEPLOT)


# In[ ]:


grid.learning_curve()
if N_runs>10:
    saveplot('obstacle_learning_curve',SAVEPLOT=SAVEPLOT)

