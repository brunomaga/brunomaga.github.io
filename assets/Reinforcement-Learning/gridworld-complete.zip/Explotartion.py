
# coding: utf-8

# In[ ]:

get_ipython().magic(u'matplotlib inline')
import numpy as np


# In[ ]:

execfile('plotting.py')
import matplotlib.pylab as plt
import gridworld as gw
gw=reload(gw)

SAVEPLOT=False
if SAVEPLOT:
    sns.set_context("paper",font_scale=1.5)
else: 
    sns.set_context("poster")


# # Exploration-exploitation 
# The parameter  controls the balance between exploration and exploitation (why?). See how different values of 0 ≤  ≤ 1 change
# the performance. For the comparison, you could plot several learning curves for
# different values of  or use e. g. the average latency in the last 10 trials as a performance measure. Let  decrease from a large value at the beginning to a small
# value at the end of training.

# In[ ]:

import  pickle
import pandas as pd
def Analyse_Model(parameter,parameter_range,parameter_Name=None,N_runs=1,N_trials=11,keywords={},Save=True):
    
    if parameter_Name is None:
        parameter_Name=parameter
        
    models={}
    results=np.zeros((len(parameter_range),N_runs))

    for i,V in enumerate(parameter_range):

        k={parameter: V}
        k.update(keywords)
        
        models[V]=gw.ContinuousWorld(**k)
        model=models[V]

        model.run(N_trials,N_runs)
        
        assert N_trials > 10
        
        results[i,:]=model.latency_table[:,-10:].mean(1)
        
    # save results
    if Save:
        pickle.dump(models,open('../Results/%s.pkl'% parameter,'w'))
    
        with open('../Results/%s.txt'% parameter,'w') as resultfile:
            resultfile.write('# '+str(keywords))
            pd.DataFrame(results,index=parameter_range).to_csv(resultfile,index=False)

    
    plot_results(parameter,parameter_range,parameter_Name,results,SAVEPLOT=Save)
    return models,results
    
def plot_results(parameter,parameter_range,parameter_Name,results,SAVEPLOT=True):
        
        if SAVEPLOT:
            sns.set_context("paper",font_scale=1.5)
        else: 
            sns.set_context("poster")
        
        data=pd.DataFrame(results.T)
        data.columns=parameter_range
        #sns.boxplot(x=data)
        plt.plot(results.mean(1),'-',label='mean')
        plt.legend(loc='upper left')
        sns.stripplot(data=data,jitter=0.3,size=8,edgecolor="gray")


        # plt.boxplot(results.T)
        # plt.gca().set_xticklabels(parameter_range)
        plt.ylim([10,1e4])
        plt.xlabel(parameter_Name)
        plt.ylabel('latency score')
        plt.yscale('log')
        saveplot(parameter,SAVEPLOT=SAVEPLOT)
        

def smoothing(x,width=3):
    """calculate a running average over the latencies with a averaging time 'width'"""
    y=x.copy()
    for i in range(1, x.shape[0]):
        y[i] = y[i-1] + (y[i] - y[i-1])/float(width)
    return y


# In[ ]:

parameter='exploration_factor'
parameter_range= [1.,0.7,0.5,0.3,0.1,0.01]
parameter_Name='exploration factor $\epsilon$'
# models,results=Analyse_Model(parameter,parameter_range,parameter_Name=parameter_Name,
#                              N_runs=10,N_trials=30,
#                              Save=True)





models=pickle.load(open('../Results/exploration_factor.pkl'))
results=pd.read_csv('../Results/exploration_factor.txt',comment='#',header=None)


# In[ ]:

plot_results(parameter,parameter_range,parameter_Name,results.values,SAVEPLOT=True)


# # Decreasing learning rate

# In[ ]:

gw=reload(gw)


# In[ ]:

parameter='Train_length'
parameter_range= [75,50,25]
parameter_Name='Proportion of training'
models,results=Analyse_Model(parameter,parameter_range,parameter_Name=parameter_Name,
                             keywords=dict(exploration_factor=[1,0.1],obstacle=True),
                             N_trials=100,N_runs=10,
                             Save=False)



# suffix='_noObstacle_Run5010'#'_obstacle_Run10010'#

# models=pickle.load(open('../Results/Train_length%s.pkl'%suffix))
# results=pd.read_csv('../Results/Train_length%s.txt'%suffix,comment='#',header=None)


# In[ ]:

for i,k in enumerate(models.keys()):
    
    #models[k].learning_curve()
    
    model=models[k]
    learning_curve=smoothing(np.median(model.latency_table,0))
    
    Length=len(model.latencies)
    c=sns.color_palette()[i]
    plt.fill_between(np.arange(1,k*Length+1),learning_curve[:int(k*Length)],color=c,alpha=0.5)
    plt.plot(np.arange(1,Length+1),learning_curve,color=c,label=int(k*Length))
    plt.yscale('log')
    plt.xlim([1,Length])
plt.xlabel('trials')
plt.ylabel('time to reach target')
    
plt.legend(title='Training steps')
saveplot('decreasing_learning_curves',SAVEPLOT=SAVEPLOT)


# In[ ]:

import pickle


def load(name,obstacle=False):
    
    model=pickle.load(open('../Results/%s.pkl' % name,'r'))
    grid=gw.ContinuousWorld(obstacle=obstacle)
    # copy values 
    grid.reward_table_=model.reward_table_
    grid.latencies=model.latencies
    grid.weights_=model.weights_
    grid.latency_table=model.latency_table
    return grid 



parameter='exploration_factor'
parameter_Name='exploration factor $\epsilon$'


models=pickle.load(open('../Results/exploration_factor.pkl'))
results=pd.read_csv('../Results/exploration_factor.txt',comment='#',header=None)


scores=pd.DataFrame(results.T)
scores.columns=[1.,0.7,0.5,0.3,0.1,0.01]

scores=scores.drop(0.01,1)



parameter_names=['0.5\nobstacle','decreasing\nobstacle','decreasing\nno obstacle']

for i,name in enumerate(['ObstacleRun100_10','Decreasing_obstacle_Run100_10','Decreasing_Run50_10']):
    grid=load(name)
    scores[parameter_names[i]]=grid.latency_score()
    


# In[ ]:

# plot 



sns.set_context("paper",font_scale=1.5)

    
plt.figure(figsize=(10,4))
plt.plot(scores.mean(0)[:5],'k',alpha=0.5)

sns.stripplot(data=scores,jitter=0.3,size=8,edgecolor="gray",alpha=0.7)

plt.plot(scores.mean(0),'*',label='mean',c='k',markersize=10)

# plt.boxplot(results.T)
#plt.gca().set_xticklabels(parameter_names)
plt.ylim([10,1e4])
plt.xlabel(parameter_Name)
plt.ylabel('latency score')
plt.yscale('log')
plt.legend()
saveplot('decreasing_obstacle',SAVEPLOT=SAVEPLOT)


# In[ ]:



