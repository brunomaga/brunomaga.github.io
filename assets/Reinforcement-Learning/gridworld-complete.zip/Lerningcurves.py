
# coding: utf-8

# Learning curve: Simulate at least 10 independent rats that run 50 trials each.
# If within a trial, the rat does not find the goal within Nmax steps, abort the trial.
# Depending on your implementation, choose e. g. Nmax = 10000. Plot the learning
# curve, i. e. the number of time steps it takes in each trial until the goal is reached
# (”latency”), averaged over all rats. If your implementation is correct, the curve
# should decrease and reach a plateau after a certain number of trials.

# In[ ]:

get_ipython().magic(u'matplotlib inline')
import numpy as np
execfile('plotting.py')
import pandas as pd

SAVEPLOT=False
if SAVEPLOT:
    sns.set_context("paper",font_scale=1.5)
else: 
    sns.set_context("poster")
    
import pickle


# In[ ]:


import matplotlib.pylab as plt
import gridworld as gw
gw=reload(gw)


np.random.seed(0)
cont =gw.ContinuousWorld(n_max=1e4)


# In[ ]:

cont =gw.ContinuousWorld(exploration_factor=[1.,0.1])
cont.run(10)


cont.run(50,20)


pickle.dump(cont,open('../Results/5020Run.pkl','w'))

# In[ ]:

model=pickle.load(open('../Results/5020Run.pkl','r'))
cont.reward_table_=model.reward_table_
cont.latencies=model.latencies
cont.weights_=model.weights_
cont.latency_table=model.latency_table


# In[ ]:

cont.learning_curve(True)
#plt.yscale('log')



saveplot('learning_curve',SAVEPLOT=SAVEPLOT)


# In[ ]:

N=cont.reward_table_.shape[0]

reward_times=np.zeros(N)

lat_times=np.zeros(N) # latencies when first achive full reward

for i in range(N):
    a=cont.reward_table_[i]
    reward_times[i] = np.where(a>0)[0][0]
    a=cont.latency_table[i]
    lat_times[i]=np.where(a<(a.max()/2.))[0][0]

    
df=pd.DataFrame()
df['positive reward']=reward_times
df['latency drop']=lat_times


plt.plot(df.T,'k',linewidth=2)
sns.stripplot(data=df,jitter=0.05,size=12)

plt.ylabel('number of trials')
saveplot('Comparison_reward_latency',SAVEPLOT=SAVEPLOT)



# In[ ]:

cont.integrated_reward()
plt.ylim([-30,20])
saveplot('integrated_reward',SAVEPLOT=SAVEPLOT)



# In[ ]:

cont.plot_Q()
saveplot('Qvalues',SAVEPLOT=SAVEPLOT)


# In[ ]:

cont.navigation_map()
saveplot('navigation_map',SAVEPLOT=SAVEPLOT)


# In[ ]:


cont.plot_neuron_arrows() # fro imageshow
saveplot('neuron_arrows',SAVEPLOT=SAVEPLOT)



# In[ ]:




# In[ ]:



