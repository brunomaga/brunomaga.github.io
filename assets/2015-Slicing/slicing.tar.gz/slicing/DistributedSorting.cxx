#include <cmath>
#include <stdint.h>
#include <limits>
#include <assert.h>
#include <stdlib.h>
#include "DistributedSorting.h"
#include <string.h> //memcpy

void DistributedSorting::checkSortingResults(
        long long pre_count,
        long double pre_sum,
        long long post_count,
        long double post_sum,
        double * coords,
        long long n,
        int sortDimension,
	MPI_Comm mpiComm,
        bool outputWarnings
        ) {
    int mpiRank = -1, mpiSize = -1;

    double *post_mins = NULL, *post_maxs = NULL;

    MPI_Comm_rank(mpiComm, &mpiRank);
    MPI_Comm_size(mpiComm, &mpiSize);

    //basic checksum
    if (outputWarnings && mpiRank == 0 && std::abs(pre_sum - post_sum) < 0.000001 )
        OutputHandler::Warning("Data checksum validation failed: "
            "the sum of all elements' coordinates in the system before (%.15llf) and after the sorting"
            "(%.15llf) differ - possibly due to numeric overflow or system dependent bug? (FLAG13)", pre_sum, post_sum);

    if (mpiRank == 0 && pre_count != post_count)
        OutputHandler::Warning("Data validation failed: "
            "the number of elements in the system before (%lld) and after the sorting"
            "(%lld) differ - possibly due to numeric overflow or system dependent bug? (FLAG14)", pre_count, post_count);

    if (mpiRank == 0) {
        post_mins = new double[mpiSize];
        post_maxs = new double[mpiSize];
    }

    //All processes send to processor zero its min and max value (for checking)
    MPI_Gather(&(coords[sortDimension]), 1, MPI_DOUBLE, post_mins, 1, MPI_DOUBLE, 0, mpiComm);
    MPI_Gather(&(coords[(n - 1)*3 + sortDimension]), 1, MPI_DOUBLE, post_maxs, 1, MPI_DOUBLE, 0, mpiComm);

    if (outputWarnings && mpiRank == 0) {
        for (int i = 1; i < mpiSize; i++) 
            if ( post_mins[i] < post_maxs[i-1])
                OutputHandler::Warning("Sorting failed: rank %d has max value %f, and rank %d has min valye %f. (FLAG15)", i-1, post_maxs[i-1], i, post_mins[i]);
    }
    fflush(stdout);

    if (mpiRank == 0) {
        delete [] post_mins; post_mins=NULL;
        delete [] post_maxs; post_maxs=NULL;
    }
}

/******************************************************************/
/*    Odd-Even Transposition Sort - MPI implementation            */
/******************************************************************/

/** NOTE:
 * From my calculations, 1GB RAM will limit the ammount of segments to about 50Million.
 * If we need to increase this probably we will have to use file system, and
 * the temp data structs in a file.
 */
long long DistributedSorting::oddEvenSort(long long n, double *coords, int sortDimension, MPI_Comm mpiComm, bool outputWarnings) {

    //Variables used for the pre and post check of the sorting (results validation)
    long double pre_sum = 0, post_sum = 0;
    long long pre_count = 0, post_count = 0;

    //OutputHandler::show("rank %d: Performing Odd Evern Sorting (MPI), dimmension %d, %lld segments.",_rank, sortDimension, segmentsCount);

    //Communication vars
    int mpiSize, mpiRank, oddRank, evenRank;
    MPI_Status status;

    //received data
    double *recvCoords;
    long long recvCount_odd = 0, recvCoordsCount_even = 0;
    long long maxCount;

    /* Get communicator-related information */
    MPI_Comm_size(mpiComm, &mpiSize);
    MPI_Comm_rank(mpiComm, &mpiRank);

    if (n == 0)
        OutputHandler::Warning("Cant continue sorting operation : rank %d has no segments at all", mpiRank);

    Slicing::getGlobalInformation(n, coords, &pre_count, &pre_sum, mpiComm);

    //Array that will hold data for compare-split operations
    double * tempCoords = new double [n * 3];

    //allocates memory for temporary array (size is the max that can receive)
    MPI_Allreduce(&n, &maxCount, 1, MPI_LONG_LONG, MPI_MAX, mpiComm);

    recvCoords = new double [maxCount * 3];

    //sorts the segments locally);
    Slicing::sort_r(coords, n, sizeof (double)*3, (void*) &sortDimension, Slicing::lessOrEqual3D);
    /*
       for (int i=0; i<mpiSize; i++ )
        {
            MPI_Barrier(MPI_COMM_WORLD);
            if (i!= mpiRank) continue;
            printf("local quickSort %d: ", mpiRank);
            for (int j=0; j<segmentsCount*3; j+=3)
                printf("(%.1f, %.1f, %.1f) ", coordinates[j], coordinates[j+1], coordinates[j+2]);
            printf("\n");
            fflush(stdout);
        }
     */

    //determines the rank of the processors with which to communicate
    if (mpiRank % 2 == 0) {
        oddRank = mpiRank - 1;
        evenRank = mpiRank + 1;
    } else {
        oddRank = mpiRank + 1;
        evenRank = mpiRank - 1;
    }

    //sets the ranks of the boundary processors
    if ((oddRank == -1) || (oddRank == mpiSize)) oddRank = MPI_PROC_NULL;
    if ((evenRank == -1) || (evenRank == mpiSize)) evenRank = MPI_PROC_NULL;

    //gets the size of the data of the odd and even processors near by:
    MPI_Sendrecv(
            &n, 1, MPI_LONG_LONG, oddRank, 1,
            &recvCount_odd, 1, MPI_LONG_LONG, oddRank, 1,
            mpiComm, &status);

    MPI_Sendrecv(
            &n, 1, MPI_LONG_LONG, evenRank, 2,
            &recvCoordsCount_even, 1, MPI_LONG_LONG, evenRank, 2,
            mpiComm, &status);

    /* the main sorting loop */
    for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(mpiComm); //TODO REMOVE
        if (i % 2 == 1) /* odd phase */ {
            //Sends/receives data itself
            MPI_Sendrecv(
                    coords, n * 3, MPI_DOUBLE, oddRank, i + 3,
                    recvCoords, recvCount_odd * 3, MPI_DOUBLE, oddRank, i + 3,
                    mpiComm, &status);

            //	    if (oddRank!=MPI_PROC_NULL)
            //	    	printf("Iter %d odd:: ME %d and %d\n", i, mpiRank, oddRank);
            /*
                        if (oddRank!=MPI_PROC_NULL)
                        {
                            printf("Iter %d  odd:: ME %d [size %lld] and %d [size %lld]:", i, mpiRank, segmentsCount, oddRank, recvSegmentsCount_odd);
                            for (int j=0; j<recvSegmentsCount_odd*3; j+=3)
                                printf("(%.1f, %.1f, %.1f) ", recvCoordinates[j], recvCoordinates[j+1], recvCoordinates[j+2]);
                            printf("\n");
                            fflush(stdout);
                        }
             */
            compareSplit(n, coords, recvCount_odd, recvCoords, tempCoords, sortDimension, mpiRank < status.MPI_SOURCE);
        } else /* even phase */ {
            MPI_Sendrecv(
                    coords, n * 3, MPI_DOUBLE, evenRank, i + 4,
                    recvCoords, recvCoordsCount_even * 3, MPI_DOUBLE, evenRank, i + 4,
                    mpiComm, &status);

            //if (oddRank!=MPI_PROC_NULL)
            //	printf("Iter %d odd:: ME %d and %d\n", i, mpiRank, evenRank);
            /*
                            if (evenRank!=MPI_PROC_NULL)
                            {
                                    printf("Iter %d even:: ME %d [size %lld] and %d [size %lld]:", i, mpiRank, segmentsCount, evenRank, recvSegmentsCount_even);
                                    for (int j=0; j<recvSegmentsCount_even*3; j+=3)
                                            printf("(%.1f, %.1f, %.1f) ", recvCoordinates[j], recvCoordinates[j+1], recvCoordinates[j+2]);
                                    printf("\n");
                                    fflush(stdout);
                            }
             */
            compareSplit(n, coords, recvCoordsCount_even, recvCoords, tempCoords, sortDimension, mpiRank < status.MPI_SOURCE);
        }
    }

    delete [] recvCoords; recvCoords= NULL;
    delete [] tempCoords; tempCoords= NULL;

    Slicing::getGlobalInformation(n, coords, &post_count, &post_sum, mpiComm);
    checkSortingResults(pre_count, pre_sum, post_count, post_sum, coords, n, sortDimension, mpiComm, outputWarnings);

    return post_count;
}

/* Implementation of Compare and Split:
 * Looks at list coordinates of size segmentsCount*3
 * and list recvCoords of size recvSegmentsCount*3
 * and:
 * if keepSmall : puts the smallest elements into coordinates array
 * if !keepSmall: puts the greatest elements into coordinates array
 *
 * used tempCoords (size segmentsCount*3) as temporary data structure;
 */
void DistributedSorting::compareSplit(
        long long n,
        double *coords,
        long long recvCount,
        double *recvCoords,
        double *tempCoords,
        int dim,
        int keepSmall) {

    //temp array becomes coordinates, and coordinates will be the result vector
    //    double * swapPtr = coordinates;
    //    coordinates = tempCoords;
    //    tempCoords = swapPtr;
    //TODO improve this with the swap pointer
    memcpy(tempCoords, coords, n * 3 * sizeof (double));

    //performs maximum of O(n+m) operations:
    //as both lists are sorted, we go through both lists at same time and
    //compare the current position on each, for the next element to add
    if (keepSmall) { /* keep the n smaller elements */
        long long tempPos = 0, recvPos = 0;
        for (long long coordPos = 0; coordPos < n * 3; coordPos += 3) {
            //if we reached the limit of the recv array
            //or if current element of tempPos < current element in recvCoord
            if (recvPos == recvCount * 3 || tempCoords[tempPos + dim] < recvCoords[recvPos + dim]) {
                memcpy(&(coords[coordPos]), &(tempCoords[tempPos]), 3 * sizeof (double));
                tempPos += 3;
            }                //we dont need the "if reached limit of coords/temp" condition
                //as it is implicit on the for loop (temp has same size as coords)
            else {
                memcpy(&(coords[coordPos]), &(recvCoords[recvPos]), 3 * sizeof (double));
                recvPos += 3;
            }
        }
    } else {
        long long tempPos = (n - 1)*3, recvPos = (recvCount - 1)*3;
        for (long long coordPos = (n - 1)*3; coordPos >= 0; coordPos -= 3) {
            if (recvPos < 0 || tempCoords[tempPos + dim] > recvCoords[recvPos + dim]) {
                memcpy(&(coords[coordPos]), &(tempCoords[tempPos]), 3 * sizeof (double));
                tempPos -= 3;
            } else {
                memcpy(&(coords[coordPos]), &(recvCoords[recvPos]), 3 * sizeof (double));
                recvPos -= 3;
            }
        }
    }
    /*      int mpiRank, size;
            MPI_Comm_rank(MPI_COMM_WORLD, &mpiRank);
            MPI_Comm_size(MPI_COMM_WORLD, &size);

            for (int i=0; i<size; i++)
            {
                if (i==mpiRank)
                {
                    printf("CompareSplit %d (keepsmall=%d):", mpiRank, keepSmall);
                    for (int j=0; j<segmentsCount*3; j+=3)
                            printf("(%.1f, %.1f, %.1f) ", coordinates[j], coordinates[j+1], coordinates[j+2]);
                    printf("\n");
                    fflush(stdout);
                }
                MPI_Barrier(MPI_COMM_WORLD);
            }
     */
}

/******************************************************************/
/*                 Sample Sort - MPI implementation               */

/******************************************************************/

long long DistributedSorting::sampleSort(long long * n_ptr, double **coords_ptr, int dim, MPI_Comm mpiComm)
{
    //Variables used for the pre and post check of the sorting (results validation)
    long double pre_sum = 0, post_sum = 0;
    long long pre_count = 0, post_count = 0;

    double *coords = *coords_ptr;

    int bucketIndex, mpiSize, mpiRank;
    long long i;
    double *sortedData, *samples, *recvSamples = NULL;
    //this would ideally be long long, but is int as MPI_AllToAllv takes int* as parameters....
    int *bucketElemsSize, *recvElemsSize, *bucketOffsets, *recvElemsOffset;
    long long myRecvElemsSize, myRecvElemsCount;

    MPI_Comm_size(mpiComm, &mpiSize);
    MPI_Comm_rank(mpiComm, &mpiRank);
    
    if (*n_ptr == 0)
        OutputHandler::Warning("Cant continue sorting operation : rank %d has no segments at all", mpiRank);

    Slicing::getGlobalInformation(*n_ptr, coords, &pre_count, &pre_sum, mpiComm);

    /* sort local array */
    Slicing::sort_r(coords, *n_ptr, sizeof (double)*3, (void *) &dim, Slicing::lessOrEqual3D);

    /* allocate memory for the arrays that will store the samples */
    samples = new double [mpiSize];

    /* select local p-1 equally spaced elements (samples only for the dimension we consider)*/
    for (i = 1; i <= mpiSize; i++) {
        unsigned int pos = (int) ((double) (*n_ptr - 1) * i/mpiSize) *3 + dim;
        samples[i - 1] = coords[pos];
    }
    samples[mpiSize - 1] = std::numeric_limits<double>::max();

    //bug fix: as we couldnt allocate memory for N*N samples in only 1 CPU,
    //this method prevents that by using groups for sampling, i.e. a group of
    //CPU does sampling to a group master, and then group masters do sampling,
    //and send it to root 0 (master of all masters).
    if (mpiSize > SUB_SAMPLING_MINIMUM_CPUS)
    {
        /*
	if (mpiRank==0)
		OutputHandler::show("Using sampling by sub-groups, as MPI size is greater than %d...", SUB_SAMPLING_MINIMUM_CPUS);
        */
        MPI_Comm newComm;
        int newMpiSize = -1;
        int newMpiRank = mpiRank % SUB_SAMPLING_GROUP_SIZE; //[0..255];
        int newMpiGroup = floor((float) mpiRank / SUB_SAMPLING_GROUP_SIZE); //[0..63] for ranks [0..1638]
        int numberOfGroups = ceil((float)mpiSize / SUB_SAMPLING_GROUP_SIZE);

        MPI_Comm_split(mpiComm, newMpiGroup, newMpiRank, &newComm);
        MPI_Comm_size(newComm, &newMpiSize);

	//printf("mpiRank %d, number groups = %d, newMpiGroup = %d, newMpiRank = %d, newMpiSize = %d;\n", mpiRank, numberOfGroups, newMpiGroup, newMpiRank, newMpiSize);

        if (newMpiRank == 0)
            recvSamples = new double [newMpiSize * (mpiSize - 1)];
          
        /* gathers the samples into the master of his group */
        MPI_Gather(samples, mpiSize - 1, MPI_DOUBLE, recvSamples, mpiSize - 1, MPI_DOUBLE, 0, newComm);

        /* masters select the samples among all received samples, in order to broadcast them */
        if (newMpiRank == 0) {

	    qsort(recvSamples, newMpiSize * (mpiSize - 1), sizeof (double), Slicing::lessOrEqual);

            for (i = 1; i < mpiSize; i++)
                samples[i - 1] = recvSamples[i * newMpiSize - 1];
            samples[mpiSize - 1] = std::numeric_limits<double>::max();

            delete [] recvSamples; recvSamples=NULL;

            /*
	    for (int j = 0; j < mpiSize; j++)
	    {
               	printf("sub sample rank %d, j=%d (%f)\n", mpiRank, j, samples[j]);
            	fflush(stdout);
	    }*/

        }
        MPI_Comm_free(&newComm);

        //sub sampling is now complete, so masters of sub groups will do the same
        //step with master of mpiComm group...
        //group number will be the rank in this group of masters
        MPI_Comm_split(mpiComm, newMpiRank, newMpiGroup, &newComm);

        if (newMpiRank == 0) //if it was a master before...
        {
            //Rank 0 will collect all samples from previous masters, and take samples of their samples!
            if (mpiRank == 0)
	        recvSamples = new double [numberOfGroups * (mpiSize - 1)];

            MPI_Gather(samples, mpiSize - 1, MPI_DOUBLE, recvSamples, mpiSize - 1, MPI_DOUBLE, 0, newComm);

	    if (mpiRank ==0)
	    {
       	    	//master takes samples of received samples...
	        qsort(recvSamples, numberOfGroups * (mpiSize - 1), sizeof (double), Slicing::lessOrEqual);

       	    	for (i = 1; i < mpiSize; i++)
	            samples[i - 1] = recvSamples[i * numberOfGroups - 1];
	        samples[mpiSize - 1] = std::numeric_limits<double>::max();

		/*
            	for (int i = 0; i<mpiSize; i++)
	    	{
	    	    printf("FINAL SAMPLE %d == %f\n", i, samples[i]);
            		fflush(stdout);
	    	}*/
		delete [] recvSamples; recvSamples=NULL;
	    }
        }
        MPI_Comm_free(&newComm);
    }
    else //basic version: simple and fast
    {
	if (mpiRank == 0)
            recvSamples = new double [mpiSize * (mpiSize - 1)];

        /* gather the samples into the master */
        MPI_Gather(samples, mpiSize - 1, MPI_DOUBLE, recvSamples, mpiSize - 1, MPI_DOUBLE, 0, mpiComm);

        /* master selects the samples among all received samples, in order to broadcast them */
        if (mpiRank == 0) 
	{
        /* for (int j = 0; j < mpiSize * (mpiSize - 1); j++)
              printf("recvSample before %04d %06d (%.1f)\n", mpiRank, j, recvSamples[j]);
           printf("\n");
       */
            qsort(recvSamples, mpiSize * (mpiSize - 1), sizeof (double), Slicing::lessOrEqual);

         /* for (int j = 0; j < mpiSize * (mpiSize - 1); j++)
                printf("recvSample quicksort %04d %06d (%.1f)\n", mpiRank, j, recvSamples[j]);
            printf("\n");
         */
            for (i = 1; i < mpiSize; i++)
                samples[i - 1] = recvSamples[i * mpiSize - 1];
            samples[mpiSize - 1] = std::numeric_limits<double>::max();

	    delete [] recvSamples; recvSamples=NULL;
	}
    }

    /* now the samples array contains the global samples */
    MPI_Bcast(samples, mpiSize, MPI_DOUBLE, 0, mpiComm);

    /* compute the number of elements that belong to each bucket */
    bucketElemsSize = new int [mpiSize];
    for (i = 0; i < mpiSize; i++) bucketElemsSize[i] = 0;

    bucketIndex = 0;
    while (coords[0 + dim] >= samples[bucketIndex])
        bucketIndex++;
    //ie gets the index of the bucket that contains our 1st coordinate

    for (i = 0; i < (*n_ptr)*3; i += 3)
        if (coords[i + dim] < samples[bucketIndex])
            bucketElemsSize[bucketIndex] += 3;
        else {
            while (coords[i + dim] >= samples[bucketIndex]) bucketIndex++;
            bucketElemsSize[bucketIndex] += 3;
        }

    //make sure there are enough samples for buckets
    //for (int i = 0; i < mpiSize; i++)
    //{   assert(bucketElemsSize[i]>0); }

    /* determine the starting location of each bucket's elements in the data array */
    bucketOffsets = new int [mpiSize];
    bucketOffsets[0] = 0;
    for (i = 1; i < mpiSize; i++)
        bucketOffsets[i] = bucketOffsets[i - 1] + bucketElemsSize[i - 1];
    // *3 in order to include the XYZ gap

/*
    for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        for (int j = 0; j < mpiSize; j++)
            printf("bucket offset %04d %06d (%.d)\n", mpiRank, j, bucketOffsets[j]);
        printf("\n");
        fflush(stdout);
    }
*/
    /* Perform an all2all communication to inform the corresponding processes */
    /* of the number of elements they are going to receive. */
    /* This information is stored in bucketElemsCount array */
    recvElemsSize = new int [mpiSize];
    MPI_Alltoall(bucketElemsSize, 1, MPI_INT, recvElemsSize, 1, MPI_INT, mpiComm);

/*    for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        for (int j = 0; j < mpiSize; j++)
            printf("recv size %04d %06d (%d), %d coordinates\n", mpiRank, j, recvElemsSize[j], recvElemsSize[j] / 3);
        printf("\n");
        fflush(stdout);
    }*/

    /* Based on recvElemsCount determines where in the local array the data from each processor */
    /* will be stored. This array will store the received elements as well as the final */
    /* sorted sequence.*/
    recvElemsOffset = new int [mpiSize];
    recvElemsOffset[0] = 0;
    for (i = 1; i < mpiSize; i++)
        recvElemsOffset[i] = recvElemsOffset[i - 1] + recvElemsSize[i - 1];

/*    for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        for (int j = 0; j < mpiSize; j++)
            printf("recv elems offset %04d %06d (%d)\n", mpiRank, j, recvElemsOffset[j]);
        printf("\n");
        fflush(stdout);
    }*/

    /* how many elements I will get */
    myRecvElemsSize = recvElemsOffset[mpiSize - 1] + recvElemsSize[mpiSize - 1];
    myRecvElemsCount = myRecvElemsSize / 3;
    sortedData = new double [myRecvElemsSize];
    if (sortedData == NULL)
        OutputHandler::Warning("Failed to allocate memmory for the slicing temporary datatypes. DistributedSorting.cxx :: FLAG9");

/*    for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        printf("sortedData %04d Ill receive size %lld doubles (%lld coordinates)\n", mpiRank, myRecvElemsSize, myRecvElemsCount);
        fflush(stdout);
    }
*/
    /* Each process sends and receives the corresponding elements, using the MPI__Alltoallv */
    /* operation. The arrays bucketElemsCount and bucketOffsets are used to specify the number of elements */
    /* to be sent and where these elements are stored, respectively. The arrays recvElemsCount */
    /* and recvElemsOffset are used to specify the number of elements to be received, and where these */
    /* elements will be stored, respectively. */
    MPI_Alltoallv(coords, bucketElemsSize, bucketOffsets, MPI_DOUBLE, sortedData, recvElemsSize, recvElemsOffset, MPI_DOUBLE, mpiComm);

/*    for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        for (int j = 0; j < myRecvElemsCount * 3; j += 3)
            printf("recv b4 quick sort %04d %06d (%.1f, %.1f, %.1f)\n", mpiRank, j / 3, sortedData[j], sortedData[j + 1], sortedData[j + 2]);
        printf("\n");
        fflush(stdout);
    }
*/

    /* perform the final local sort */
    Slicing::sort_r(sortedData, myRecvElemsCount, sizeof (double)*3, (void*) &dim, Slicing::lessOrEqual3D);

/*  for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        for (int j = 0; j < myRecvElemsCount * 3; j += 3)
            printf("recv after quick sort %04d %06d (%.1f, %.1f, %.1f)\n", mpiRank, j / 3, sortedData[j], sortedData[j + 1], sortedData[j + 2]);
        printf("\n");
        fflush(stdout);
    }*/

    /* Validates sorting*/
    Slicing::getGlobalInformation(myRecvElemsCount, sortedData, &post_count, &post_sum, mpiComm);
    checkSortingResults(pre_count, pre_sum, post_count, post_sum, sortedData, myRecvElemsCount, dim, mpiComm);
 
    /*  for (int i = 0; i < mpiSize; i++) {
        MPI_Barrier(MPI_COMM_WORLD);
        if (i != mpiRank) continue;
        for (int j = 0; j < myRecvElemsCount * 3; j += 3)
            printf("before function exit %04d %06d (%.1f, %.1f, %.1f)\n", mpiRank, j / 3, (*coordinates_ptr)[j], (*coordinates_ptr)[j + 1], (*coordinates_ptr)[j + 2]);
        printf("\n");
        fflush(stdout);
    }*/

    
    /* cleanup */
    delete [] samples; samples = NULL;
    delete [] bucketElemsSize; bucketElemsSize = NULL;
    delete [] bucketOffsets; bucketOffsets = NULL;
    delete [] recvElemsSize; recvElemsSize = NULL;
    delete [] recvElemsOffset; recvElemsOffset = NULL;
    delete [] coords; coords = NULL;
    
    *coords_ptr = sortedData;
    *n_ptr = myRecvElemsCount;

    return post_count;
}

