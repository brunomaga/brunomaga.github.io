#include <cmath>
#include <algorithm> //std::min, std::max
#include "DistributedLoadBalancing.h"

void DistributedLoadBalancing::checkLoadBalancingResults(
	long long pre_count,
	long double pre_sum,
	long long post_count,
	long double post_sum,
	long long myCount,
	MPI_Comm mpiComm,
        bool outputWarnings
	)
{
    int mpiRank=-1;
    long long minCount=-1, maxCount=-1;
    MPI_Comm_rank(mpiComm, &mpiRank);

    //basic checksum
    if (outputWarnings && mpiRank == 0 && std::abs(pre_sum - post_sum) < 0.000001 )
        OutputHandler::Warning("Load checksum balancing failed: "
            "the sum of all elements in the system before (%.15llf) and after the sorting/balancing"
            "(%.15llf) differ - possibly due to numeric overflow or system dependent bug? (FLAG11)", pre_sum, post_sum);

    if (mpiRank == 0 && pre_count != post_count)
        OutputHandler::Warning("Load balancing failed: "
            "the number of elements in the system before (%lld) and after the sorting/balancing"
            "(%lld) differ - possibly due to numeric overflow or system dependent bug? (FLAG12)", pre_count, post_count);

    //Root gets the minimum and maximum number of elements
    MPI_Reduce(&myCount, &minCount, 1, MPI_LONG_LONG, MPI_MIN, 0, mpiComm);
    MPI_Reduce(&myCount, &maxCount, 1, MPI_LONG_LONG, MPI_MAX, 0, mpiComm);

//  OutputHandler::show("- rank %d, segmentsCount=%lld", mpiRank, mySegmentsCount);
    if (mpiRank == 0 && maxCount - minCount >1 )
        OutputHandler::Warning("Load balancing not accurate: the gap between the highest and lowest number of elements is %lld (expected 0 or 1). (FLAG10)", maxCount - minCount);
    fflush(stdout);
}


int DistributedLoadBalancing::loadBalancing(long long * n_ptr, double ** coords_ptr, MPI_Comm mpiComm, bool outputWarnings)
{
    //Initialization of MPI variables
    int mpiSize = -1, mpiRank = -1;
    MPI_Comm_size(mpiComm, &mpiSize);
    MPI_Comm_rank(mpiComm, &mpiRank);

    long long pre_count, post_count;
    long double pre_sum,  post_sum;
    Slicing::getGlobalInformation(*n_ptr, *coords_ptr, &pre_count, &pre_sum, mpiComm);

    long long globalCount = pre_count;

    //each CPU gets the current number of elements of all the others
    long long * allCounts = new long long[mpiSize];
    MPI_Allgather(n_ptr, 1, MPI_LONG_LONG, allCounts, 1, MPI_LONG_LONG, mpiComm);

    //calculates the number of segments to be sent to each processor
    int * sentElemsSize = new int [mpiSize];
    for (int i = 0; i < mpiSize; i++) 
	sentElemsSize[i] = 0;

    //global index of beginning & end of my data (inclusive)
    long long myStartPos = 0, myEndPos=-1;
    for (int i = 1; i <= mpiRank; i++)
	myStartPos+= allCounts[i-1];
    myEndPos=myStartPos+allCounts[mpiRank]-1;

    delete [] allCounts; allCounts=NULL;
    
/*  for (int i=0; i<mpiSize; i++ )
        {
            MPI_Barrier(MPI_COMM_WORLD);
            if (i!= mpiRank) continue;
            OutputHandler::show("mpiRank %d :: my %lld segments are between %lld and %lld",mpiRank, *mySegmentsCount_ptr, myStartPos, myEndPos);
            fflush(stdout);
        }
*/

    //number of final elements per cpu
    long long * elementsCountPerCpu = new long long [mpiSize];
    for (int i=0; i<mpiSize; i++)
        elementsCountPerCpu[i] = floor ((long double) globalCount / mpiSize) + ( i < globalCount % mpiSize ? 1 : 0);

    //global index of beginning & end of future slices (inclusive)
    long long indexStart = 0;
    for (int i = 0; i < mpiSize; i++)
    {
        long long indexEnd = i==(mpiSize-1) ? globalCount-1 : indexStart + elementsCountPerCpu[i] -1; //inclusive

        //if (mpiRank==0) OutputHandler::show("slice %d indexStart=%lld indexEnd=%lld (size=%lld)", i, indexStart, indexEnd, indexEnd - indexStart +1 );

	sentElemsSize[i] = 0;

	//if the two intervals have regions in commmon (ie intersect)
	if (!(indexStart > myEndPos || indexEnd < myStartPos))
	{
	    //if they intersect, the data to be sent is the size of the intersection
	    //(+1 because beginning and end positions are inclusive
	    sentElemsSize[i] = (int) (std::min(indexEnd, myEndPos) - std::max(indexStart, myStartPos) +1);
	    sentElemsSize[i] *=3; //because we send coordinates

	    //OutputHandler::show("rank %d: slice %d intersect with size %d", mpiRank, i, sentElemsSize[i]/3);
	}
	//else
	//    OutputHandler::show("slice %i doesnt intersect", i);

	indexStart += elementsCountPerCpu[i];
    }
 /*      for (int i=0; i<mpiSize; i++ )
        {
            MPI_Barrier(MPI_COMM_WORLD);
            if (i!= mpiRank) continue;
            printf("sentElemssize %d: ", mpiRank);
            for (int j=0; j<mpiSize; j++)
                printf(" %07d ", sentElemsSize[j]/3);
            printf("\n");
            fflush(stdout);
        }
*/
    delete [] elementsCountPerCpu; elementsCountPerCpu = NULL;

    //calculates the offset on his data, for the received data from the other ranks.
    int * sentElemsOffset = new int[mpiSize];
    sentElemsOffset[0] = 0;
    for (int i = 1; i < mpiSize; i++)
        sentElemsOffset[i] = sentElemsOffset[i - 1] + sentElemsSize[i - 1];

/*     for (int i=0; i<mpiSize; i++ )
        {
            MPI_Barrier(MPI_COMM_WORLD);
            if (i!= mpiRank) continue;
            printf("sentElemsOffset %d: ", mpiRank);
            for (int j=0; j<mpiSize; j++)
                printf(" %07d ", sentElemsOffset[j]/3);
            printf("\n");
            fflush(stdout);
        }*/
    
    //calculate the ammounf of data received from each rank
    int * recvElemsSize = new int [mpiSize];
    MPI_Alltoall(sentElemsSize, 1, MPI_INT, recvElemsSize, 1, MPI_INT, mpiComm);

    //calculate the offset of the data received
    int * recvElemsOffset = new int [mpiSize];
    recvElemsOffset[0] = 0;
    for (int i = 1; i < mpiSize; i++)
        recvElemsOffset[i] = recvElemsOffset[i - 1] + recvElemsSize[i - 1];

/*    for (int i=0; i<mpiSize; i++ )
        {
            MPI_Barrier(MPI_COMM_WORLD);
            if (i!= mpiRank) continue;
            printf("recvElemsOffset %d: ", mpiRank);
            for (int j=0; j<mpiSize; j++)
                printf(" %07d ", recvElemsOffset[j]/3);
            printf("\n");
            fflush(stdout);
        }*/

    //calculate final size for data received and allocates memory
    int myRecvElemsSize = recvElemsOffset[mpiSize - 1] + recvElemsSize[mpiSize - 1];
    double * recvCoordinates = new double[myRecvElemsSize];

    MPI_Alltoallv(*coords_ptr, sentElemsSize, sentElemsOffset, MPI_DOUBLE, recvCoordinates, recvElemsSize, recvElemsOffset, MPI_DOUBLE, mpiComm);

    delete [] (*coords_ptr);
    *coords_ptr = recvCoordinates;
    *n_ptr = myRecvElemsSize / 3;

    Slicing::getGlobalInformation(*n_ptr, *coords_ptr, &post_count, &post_sum, mpiComm);
    checkLoadBalancingResults(pre_count, pre_sum, post_count, post_sum, *n_ptr, mpiComm, outputWarnings);


/*      for (int i=0; i<mpiSize; i++ )
        {
            MPI_Barrier(MPI_COMM_WORLD);
            if (i!= mpiRank) continue;
            printf("myElems %d: ", mpiRank);
            for (int j=0; j<12; j+=3)
                printf(" (%f,%f,%f)", (*coordinates_ptr)[j], (*coordinates_ptr)[j+1], (*coordinates_ptr)[j+2]);
	    printf("\n");
            for (int j=(*mySegmentsCount_ptr-1)*3; j>(*mySegmentsCount_ptr-4)*3; j-=3)
                printf(" (%f,%f,%f)", (*coordinates_ptr)[j], (*coordinates_ptr)[j+1], (*coordinates_ptr)[j+2]);
            printf("\n");
            fflush(stdout);
          }*/

    delete [] recvElemsOffset; recvElemsOffset=NULL;
    delete [] recvElemsSize; recvElemsSize=NULL;
    delete [] sentElemsOffset; sentElemsOffset=NULL;
    delete [] sentElemsSize; sentElemsSize=NULL;
    
    return post_count;

}
