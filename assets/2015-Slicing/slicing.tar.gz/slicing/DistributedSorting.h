#pragma once

#include "Slicing.h"

/*
 * Defines the size of each group used for sub sampling in the Sample Sort
 * algorithm.\n\n
 * Example: for 16384 CPUs (full machine), if SUB_SAMPLING_GROUP_SIZE
 * is set as 2048, then we do sampling for [0..2043, 2044..4095, 4096.. 8172, etc].
 * After that, all 8 masters (1 for each group) will do the same procedure with
 * a unique master (rank 0);
 */
#define SUB_SAMPLING_GROUP_SIZE 128

/*
 * Determines the minumum number of CPUs used for subsampling in Sample Sort
 * algorithm.
 */
#define SUB_SAMPLING_MINIMUM_CPUS 4096

/**
 * Class with static methods to handle distributed memmory sort.
 * Two algorithms available: Odd Even sort and Sample sort
 */
class DistributedSorting{

public:

     /**
      * Performs an Odd Even sorting parallel algorithm.\n
      * This methods is slower than the parallel Sample Sort, but it has the
      * advantadge of each CPU holding always the same amount of coordinates
      * that were inputed.\n
      * Approximate memory usage is 3 times the size of input coordinates array.
      * @param n (IN) number of coordinates that will be input
      * - by definition, its also the ammount of elements to be output.
      * @param coordinates (IN/OUT) original and sorted coordinates
      * @param sortDimension (IN) sorting dimensions
      * @return returns the number of segments in the total system, i.e. sum of the segments of all CPUs.
      */
     static long long oddEvenSort( long long n, double *coordinates, int sortDimension, MPI_Comm mpiComm, bool outputWarnings = false);

     /**
      * Performs a parallel Sample Sort.\n
      * This algorithm is a very fast implementation of a distributed memory
      * sort, but results on a different number of segments per CPU. Use
      * OddEvenSort_MPI instead, if you want the same number of segments per CPU.\n
      * \n
      * \nIt validades the results by performing the 3 follwing checks
      * \n - checks if total number of elements in the system are the same (before and after)
      * \n - checks if sum of all elements in the system are the same (before and after)
      * \n - checks if they are sorted - ie. max(rank)<min(rank+1)<max(rank+1)<min(rank+2)<... , for all ranks
      * @param n_ptr (IN/OUT) number of coordinates input (and output).
      * After execution will be updated with the number of segments on the new
      * sorted coords. I.e. its a pointer to the count;
      * @param coordinates_ptr (IN/OUT) contains all coordinates: a pointer to the array containing all coordinates
      * After execution it holds an arrays set of (probably differente size), holding sorted coordinates
      * @param (IN) sortDimension sorting dimension
      * @return returns the number of segments in the total system, i.e. sum of the segments of all CPUs.
      */
     static long long sampleSort( long long * n_ptr, double **coords_ptr, int dim, MPI_Comm mpiComm);

private:
    
     /**
      * Performs a Compare Split ordering: \n
      * Receives two ALREADY SORTED arrays (coordinates and recvCoords), with
      * segmentsCount and recvSegmentsCount segments respectively.
      * Uses tempCoords as temporary array for the calculation (same size of
      * segmentsCount).\n
      * Output is returned as the coordinates array, sorted by dimension dim.
      * If keepsmall is 0, it will contains the biggest of the comparison
      * Otherwise it will return the smallest elements of the comparison\n
      * EG: basic compare split for [1,5,8,10,11] (coords) and [1,3,9] (recv):\n
      * if keepsmall returns [1,1,3,5,8]\n
      * if !keepSmall returns [9,10,11].
      * This algorithm does the same but takes coordinates instead of numbers.
      * \n
      * It validades the results by performing the 3 follwing checks
      * \n - checks if total number of elements in the system are the same (before and after)
      * \n - checks if sum of all elements in the system are the same (before and after)
      * \n - checks if they are sorted - ie. max(rank)<min(rank+1)<max(rank+1)<min(rank+2)<... , for all ranks
      * @param n (IN) number of coordinates in coordinates array
      * @param coords (IN/OUT) coordinates array (format [x0,y0,z0, x1,y1,z1, x2,y2,z2, ...]
      * @param recvSegmentsCount (IN) number of segments/coordinates in recvCoords array
      * @param recvCoords (IN) second coordinates array (same formate as coordinates)
      * @param tempCoords (IN) an array with same size ad type as coordinates - to be used as intermediatte data
      * structure for the calculation. Data to be allocated before calling this functions, and to be freed after.
      * @param dim (IN) dimension for sorting
      * @param keepSmall (IN) Zero or Not, whether we keep bigger or smaller portion of elements (as description)
      */
     static void compareSplit(long long n, double *coords, long long recvSegmentsCount, double *recvCoords, double* tempCoords, int dim, int keepSmall);

     /**
      * Performs all checkings that validate the sorting, i.e. it validades the results by performing the 3 follwing checks
      * \n - checks if total number of elements in the system are the same (before and after)
      * \n - checks if sum of all elements in the system are the same (before and after)
      * \n - checks if they are sorted - ie. max(rank)<min(rank+1)<max(rank+1)<min(rank+2)<... , for all ranks
      *
      * Usage: \n
      * - 1st: call getGlobalInformation(...) before the sorting to get preCheck variables
      * - 2nd: call getGlobalInformation(...) after the sorting to get postCheck variables
      * - 3rd: call checkSortingResults(...) with previous variables (to validate the first 2 conditions mentioned above)
      * and the coordinates array, the number of coordinates, and the sort dimension (to check the 3d condition)
      * @param preCheck_globalValuesCount (IN) count of all elements in the whole system - before sorting
      * @param preCheck_globalValuesSum (IN) sum of all elements in the whole system - before sorting
      * @param postCheck_globalValuesCount (IN) count of all elements in the whole system - after sorting
      * @param postCheck_globalValuesSum (IN) sum of all elements in the whole system - after sorting
      * @param coordinates (IN) coordinates array AFTER the sorting
      * @param segmentsCount (IN) number of segments in coordinates. Coordinates size = segments*3
      * @param sortDimension (IN) dimension to consider
      * @param mpiComm MPI communicator
      */
     static void checkSortingResults(
	long long preCheck_globalValuesCount,
	long double preCheck_globalValuesSum,
	long long postCheck_globalValuesCount,
	long double postCheck_globalValuesSum,
	double * coordinates,
	long long segmentsCount,
	int sortDimension,
	MPI_Comm mpiComm,
        bool outputWarnings = false
	);
};

