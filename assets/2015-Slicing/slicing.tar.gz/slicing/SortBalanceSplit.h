#pragma once

#include "Slicing.h"

/**
 * Class responsible for slicing the initial spatial data into N subvolumes,
 * to be assigned to each CPU.Input can be either the txt file containing the
 * Slicing, or no input file which means that slicing will be computed on the fly.
 */
class SortBalanceSplit {
public:

    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, SliceDetails * finalSlicing = NULL);
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, int * slicingConfiguration, SliceDetails * finalSlicing = NULL);
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, float samplingRate, SliceDetails * finalSlicing = NULL);
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, int * slicingConfiguration, float samplingRate, SliceDetails * finalSlicing = NULL);
   
private:
    
    /**
     * Applies to Sort Title Recursive (STR) algorithm to the input volume.
     * The STR splits one dimension in N slices, then for each slices splits
     * it again in N sub-slices in the next dimension, and finally for the
     * 3rd dimensionm splits it again is sub-sub-slices\n
     * \n
     * MORE INFO: https://bbpteam.epfl.ch/confluence/display/BBPDIAS/Load+Balancing+Summary \n
     *\n
     *
     * @param dim Var used for recursive purposes (initialized as 0)
     * @param sliceNumber Var used for recursive purposes (initialized as 0)
     * @param universe struct that represents the boundaries (in terms of ranks, indices and dimension) of this volume
     * @param mySegmentsCount number of segments of this current CPU
     * @param nTouchDetectors number of cpus (touch detectors) allocated to this slice
     * @param coordinates coordinates for this slice
     */
    static void sortTileRecursive_aux(int dim, int sliceNumber, double *& coords, long long & n, int * slicingConfiguration, SliceDetails & universe, MPI_Comm mpiComm, SliceDetails * finalSlicing);

     /**
      * Returns the details for all subslices of the parameter universe.
      * @param dim dimension [0..2]
      * @param sliceNumber slice number [0..slicesCount[
      * @param universe universe data (ie, previous dimension slice)
      * @param slicesCount total number of sub slices
      * @param globalSegmentsCount total number of segments in universe
      * @param n total number of segments in this rank
      * @param coordinates coordinates array
      * @param mpiComm MPI comm
      * @return
      */
    static SliceDetails * getSubSlicesDetails(int dim, int sliceNumber, SliceDetails & universe, int slicesCount, long long n, double *coordinates, MPI_Comm mpiComm);

};


