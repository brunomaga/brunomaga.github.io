#pragma once

#include "mpi.h"

/**
 * Maximum number of slices a dimension can be split into.
 * Used by the constructor to calculate the best combination of slices in X, Y
 * and Z, such that X*Y*Z=N, where N is the number of CPUs;
 */
#define MAX_SLICES_PER_DIM 128

/**
 * Represents all boundaries around a slice, in terms of dimensions,
 * ranks and index inside of those ranks, that are handling it.
 * To be used by slicing detection, to specify the details of each slice and subslice
 */
typedef struct sliceDetails {
    double min[3]; //bottom left front corner of the subvolume
    double max[3]; //top right back corner of the subvolume

    int firstRank; //rank where this slice starts (inclusive) //TOOD rename firstSliceId
    int lastRank; //rank where this slice ends (inclusive) //TODO rename lastSliceId

    int numberOfCPUs; //number of CPUs handling this slice //TODO rename numberOfSlices
} SliceDetails;

class Slicing {

public: 

///wraps sort_r in BSD, sort_r in GNU and sort_s in windows (for qsort with argument)
static void sort_r(void *base, size_t nel, size_t width, void *arg,
            int (*compar)(const void *a1, const void *a2, void *aarg));

static int lessOrEqual3D( const void * a, const void * b, void * dim_ptr);
static int lessOrEqual(const void * a, const void * b);

/**
 * Gets the best slices combination in X, Y and Z dimensions, such that
 * X*Y*Z=N, where N is the number of cpus. 
 * Return value is an array int[3] with number of slices per dimension.
 */
static void calculateBestSlicingCombination(int *slicingConfig, MPI_Comm mpiComm);


/**
 * populates preCheck_globalValuesSum and preCheck_globalValuesCount variables with the
 * sum and count of all elements in the system
 * @param n (IN) number of Segments
 * @param coordinates (IN) array of elements
 * @param preCheck_globalValuesCount (OUT) count of all elements in the whole system - to be populated
 * @param preCheck_globalValuesSum (OUT) sum of all elements in the whole system - to be populated
 */
static void getGlobalInformation(long long n, double * coordinates, long long *check_globalValuesCount, long double *check_globalValuesSum, MPI_Comm mpiComm);

/**
 * Calculates the minumum and maximum values of all the coordinates in the
 * whole system, and places it into the return var 'universe'. Also collects
 * all coordinates of all segments - will be used for slicing calculation -
 * and places them in the coordinates array.
 * @param coordinates return array with coordinates [x0,y0,z0,x1,y1,z1,...,xN,yN,zN]
 * @param n number of coordinates
 * @return universe boundaries as a single slice
 */
static SliceDetails getUniverseBoundaries(double * coordinates, long long n, MPI_Comm mpiComm);

/**
 * Returns samples given a samplingRate
 */
static void getSamples(double * coords, long long n, float samplingRate, double *& coords_samples, long long & n_samples);

};

#include "OutputHandler.h"
#include "DistributedLoadBalancing.h"
#include "DistributedSorting.h"
#include "SortBalanceSplit.h"
#include "SerialSlicing.h"

