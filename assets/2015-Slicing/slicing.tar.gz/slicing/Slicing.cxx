#include <limits> 
#include <stdlib.h>
#include <assert.h>
#include <string.h> //memcpy

#include "Slicing.h"


void Slicing::getSamples(double * coords, long long n, float samplingRate, double *& coords_samples, long long & n_samples)
{
    assert(samplingRate>0 && samplingRate <=1);
        
    coords_samples = new double[(long long)(n*samplingRate*3)];
    
    n_samples=0;
    double jump=1/samplingRate;    
    for (double offset=0 ; offset < n ; offset += jump)
    {
        memcpy(&coords_samples[n_samples*3], &coords[(long long)(offset*3)], sizeof(double)*3 );
        n_samples++;
    }
}


///Function to make qsort_r and qsort_s compatible across several platforms
struct sort_r_data
{
  void *arg;
  int (*compar)(const void *a1, const void *a2, void *aarg);
};

int sort_r_arg_swap(void *s, const void *aa, const void *bb)
{
  struct sort_r_data *ss = (struct sort_r_data*)s;
  return (ss->compar)(aa, bb, ss->arg);
}

void Slicing::sort_r(void *base, size_t nel, size_t width, void *arg,
            int (*compar)(const void *a1, const void *a2, void *aarg))
{
  #if (defined _GNU_SOURCE || defined __GNU__ || defined __linux__)
    qsort_r(base, nel, width, compar, arg);

  #elif (defined __APPLE__ || defined __MACH__ || defined __DARWIN__ || \
         defined __FREEBSD__ || defined __BSD__ || \
         defined OpenBSD3_1 || defined OpenBSD3_9)
    struct sort_r_data tmp;
    tmp.arg = arg;
    tmp.compar = compar;
    qsort_r(base, nel, width, &tmp, &sort_r_arg_swap);

  #elif (defined _WIN32 || defined _WIN64 || defined __WINDOWS__)
    struct sort_r_data tmp = {arg, compar};
    qsort_s(*base, nel, width, &sort_r_arg_swap, &tmp);

  #else
    #error Cannot detect operating system
  #endif
}
int Slicing::lessOrEqual(const void * a, const void * b)
{
    double coordA = *(double*) a;
    double coordB = *(double*) b;
    if (coordA > coordB) return 1;
    if (coordB > coordA) return -1;
    return 0;
}

/**
 * function used by stdlib::qsort_r() to determine order of elements
 * dim = (int *) dimension
 * a = (Segment *) segmentA
 * b = (Segment *) segmentB
 */
int Slicing::lessOrEqual3D( const void * a, const void * b, void * dim_ptr)
{
    double* coordsA = (double*) a;
    double* coordsB = (double*) b;
    int dim = *(int*)dim_ptr;

    //check if they are different in the current dimension
    if (coordsA[dim] > coordsB[dim]) return 1;
    if (coordsB[dim] > coordsA[dim]) return -1;

    //if all dimensions have been checked, return 0 (equal)
    if (dim==2) return 0;

    //check next dimension
    dim++;
    return lessOrEqual3D(a, b, (void*) &dim); //sorts them by the next dimension
}

void Slicing::calculateBestSlicingCombination(int * slicingConfig, MPI_Comm mpiComm)
{
    int mpiRank=-1, mpiSize=-1;
    MPI_Comm_rank(mpiComm, &mpiRank);
    MPI_Comm_size(mpiComm, &mpiSize);
    
    int tempSum = std::numeric_limits<int>::max();

    //we want to minimize number of slices in Y direction
    for (int y=1; y <= MAX_SLICES_PER_DIM; y++)
      for (int z=y; z <= MAX_SLICES_PER_DIM; z++) 
        for (int x=z; x <= MAX_SLICES_PER_DIM; x++)
          //if xyz decompose N, and are the best combination
          if (x*y*z == mpiSize && x+y+z<tempSum)
          {
              slicingConfig[0] = x;
              slicingConfig[1] = y;
              slicingConfig[2] = z;
              tempSum = x+y+z;
          }

    //If number of CPUs is not decomposable (ie cant be sliced) print error message
    if (mpiRank !=0 ) return;

    if (tempSum == std::numeric_limits<int>::max())
        OutputHandler::Warning("Could not find a combination of slices X Y Z - from 1 to %d - such that X*Y*Z=%d cpus.", MAX_SLICES_PER_DIM, mpiSize);
}

SliceDetails Slicing::getUniverseBoundaries(double * coords, long long n, MPI_Comm mpiComm) 
{
    int mpiSize;
    MPI_Comm_size (mpiComm, &mpiSize);
    
    SliceDetails universe;
    
    //Initial and final rank and positions for this universe
    universe.numberOfCPUs = mpiSize;
    universe.firstRank = 0;
    universe.lastRank = mpiSize - 1;

    //initializes the min and max values for each dimension
    double myMin[3], myMax[3];
    for (int d = 0; d < 3; d++)
    {
        myMin[d] = std::numeric_limits<double>::max();
        myMax[d] = std::numeric_limits<double>::min();
    }
        
    //populates myMin and myMax with each CPU's min and max
    for (int i =0; i< n; i++) 
    {
        for (int d = 0; d < 3; d++) 
        {           
            if (coords[i*3+d] < myMin[d]) myMin[d] = coords[i*3+d];
            if (coords[i*3+d] > myMax[d]) myMax[d] = coords[i*3+d];
        }
    }

    /*
    int mpiRank=-1;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpiRank);
    printf("%d n=%lld, min/max =[%.2f,%.2f], [%.2f,%.2f], [%.2f,%.2f]\n",
            mpiRank, n, myMin[0], myMax[0], myMin[1], myMax[1], myMin[2], myMax[2]);
    */      
    
    //gets the system's (ie global circuit's) minimum and maximum values
    for (int d = 0; d < 3; d++)
    {
        MPI_Allreduce(&(myMin[d]), &(universe.min[d]), 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
        MPI_Allreduce(&(myMax[d]), &(universe.max[d]), 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
    }
   
    return universe;
}

void Slicing::getGlobalInformation(
        long long n,
        double * coords,
        long long *pre_count,
        long double *pre_sum,
	MPI_Comm mpiComm)
{
    /* Calculates preCheck Variables*/
    long double sum = 0;
    for (long long i = 0; i < n * 3; i++)
        sum += (long double) coords[i];
    
    MPI_Allreduce(&sum, pre_sum, 1, MPI_LONG_DOUBLE, MPI_SUM, mpiComm);
    MPI_Allreduce(&n, pre_count, 1, MPI_LONG_LONG, MPI_SUM, mpiComm);
}
