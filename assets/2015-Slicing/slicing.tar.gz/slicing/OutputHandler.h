#pragma once

/**
 * Class with static methods to output messages, output warnings, and handle errors in an organized way.
 * Includes MPI error messages checking, system error messages checking, MPI FInalization method, and
 * methods to output information "a la printf", i.e. with formatted string.
 */
class OutputHandler {
public:

    enum TYPE {Warning_msg, Normal_msg};
     /**
     * Prints an information message to the user (INCLUDING local time)
     * @param format (IN) Format of the string (just as printf), eg:\n
     * showInfo("Iteration %d out of %d..", iteration, totalIterations);\n
     * would output:\n
     * 14:20:00    Iteration 1 out of 2..
     * @param ... (IN)
     */
    
    static void show(const char* format, ...);


     /**
     * Prints an information message to the user (no local time included)
     * @param printTime (IN) whether time will be printed or not
     * @param msgType (IN) specifies whether msg will be printed as Warning, Error
     * or normal Info message
     * @param format (IN) Format of the string (just as printf), eg:
     * Warning(true, "Iteration %d out of %d..", iteration, totalIterations);
     * @param ... (IN)
     */
    static void show(bool printTime, TYPE msgType, const char * format, ...);

    /**
     * Prints a warning.
     * @param infoMsg (IN) Format of the string (just as printf), eg:\n
     * Warning("Counter %d approacing limit %d", counter, limit);
     * would output:\n
     * 14:19:23  WARNING: Counter 10 approaching limit 12
     * @param ...
     */
    static void Warning(const char* infoMsg, ...);

private:
    /**
     * Copies the local time as hh:mm:ss into the string localtime
     * @param localTime (OUT) a pointer to a char array - can have allocated
     * some memmory or past as NULL - in this case, memory will be allocated
     * @return If the resulting C string fits in less than maxsize characters
     * including the terminating null-character, the total number of characters
     * copied to ptr (not including the terminating null-character) is returned.
     * Otherwise, zero is returned and the contents of the array are indeterminate.
     */
    static int getLocalTime(char * localTime);
};

