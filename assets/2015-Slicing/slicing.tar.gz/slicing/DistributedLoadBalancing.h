#pragma once

#include "Slicing.h"

/**
 * Class with static methods to handle distributed load balancing.
 */
class DistributedLoadBalancing{

public:

     /**
      * Balances the ammount of data accross all the CPUs in the system.
      * Ie: if started by eg 4 CPUs with arrays size 3,1,5 and 7 (ie total 16),
      * after the execution they will all contains 4 elements each (4 x 4 = 16).
      * This algorithm keeps the order, ie. the final elements of an array will
      * be appended to the beginning of next rank's array. Therefore, if given
      * a set of ordered arrays, the output will still be ordered.\n
      * \n
      * The following validations are performed:\n
      * - Sum of all segments before and after is the same\n
      * - Count of all elements before and after is the same\n
      * - Gap between highest and lowest element count is either 0 or 1;
      * @param mySegmentsCount_ptr (IN/OUT) pointer to number of segments in the array
      * @param coordinates_ptr (IN/OUT) pointer to the array containing the coordinates
      * @param mpiComm MPI communicatoryy
      * @return number of segments in the whole system (after balancing)
      */
     static int loadBalancing(long long * n_ptr, double ** coordinates_ptr, MPI_Comm mpiComm, bool outputWarnings = false);

private:

     /**
      * Performs all checking necessary to validade a load balancing operation:\n
      * - Sum of all elements before and after load balancing are the same;\n
      * - Count of all elements before and after load balancing are the same;\n
      * - Gap between highest and lowest number of elements in the system is either 0 or 1;\n
      * @param preCheck_globalValuesCount (IN) count of all elements in the whole system - before sorting
      * @param preCheck_globalValuesSum (IN) sum of all elements in the whole system - before sorting
      * @param postCheck_globalValuesCount (IN) count of all elements in the whole system - after sorting
      * @param postCheck_globalValuesSum (IN) sum of all elements in the whole system - after sorting
      * @param mySegmentsCount (IN) number of elements in this cpu
      * @param mpiComm
      */
     static void checkLoadBalancingResults(
	long long preCheck_globalValuesCount,
	long double preCheck_globalValuesSum,
	long long postCheck_globalValuesCount,
	long double postCheck_globalValuesSum,
	long long myElementsCount,
	MPI_Comm mpiComm,
        bool outputWarnings = false
	);
};

