#pragma once

#include "Slicing.h"

/**
 * Class responsible for slicing the initial spatial data into N subvolumes,
 * to be assigned to each CPU.Input can be either the txt file containing the
 * Slicing, or no input file which means that slicing will be computed on the fly.
 */
class SerialSlicing {
public:
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, SliceDetails * finalSlicing = NULL);
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, int * slicingConfiguration, SliceDetails * finalSlicing = NULL);
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, float samplingRate, SliceDetails * finalSlicing = NULL);
    static void sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, int * slicingConfiguration, float samplingRate, SliceDetails * finalSlicing = NULL);

private:
    /**
     * Applies to Sort Title Recursive (STR) algorithm to the input volume.
     * The STR splits one dimension in N slices, then for each slices splits
     * it again in N sub-slices in the next dimension, and finally for the
     * 3rd dimension splits it again is sub-sub-slices\n
     */
    static void sortTileRecursive_aux(int dim, int & sliceId, double * coords, long long n, int * slicingConfiguration, SliceDetails universe, SliceDetails * finalSlicing);

};


