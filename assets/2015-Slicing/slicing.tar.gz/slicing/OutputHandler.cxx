#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "OutputHandler.h"
#include <time.h> //struct tm

#define SIZE 2048

void OutputHandler::show(const char* format, ...){
    va_list args;
    va_start (args, format);
    char message[SIZE];
    vsprintf(message, format, args);
    show(true, Normal_msg, message);
    va_end (args);
}

void OutputHandler::Warning(const char* format, ...)
{   va_list args;
    va_start (args, format);
    char message[SIZE];
    vsprintf(message, format, args);
    show(true, Warning_msg, message);
    va_end (args);
}

void OutputHandler::show(bool printTime, TYPE msgType, const char * format, ...)
{
    va_list args;
    va_start (args, format);
    char message[SIZE];

    //current position to be written in array
    int pos = 0;

    if (msgType == Normal_msg)
    {
	if (printTime)
   	 {
    		//writes characters [0-7] for the time
		pos += getLocalTime(message);
        	//writes characters 8-11 containing hh:mm:ss
        	pos += sprintf(&(message[pos]), (char*) "  ");
    	}
    	else
       		pos += sprintf(&(message[pos]), (char*) "          ");
    }

    //writes the extra information
    if (msgType == Warning_msg)
    	pos += sprintf(&(message[pos]), "Warning:  ");

    //writes the remaining chars with the message
    vsprintf(&(message[pos]), format, args);

    fprintf(stdout,"%s\n",message);
    va_end (args);
    fflush(stdout);
}

int OutputHandler::getLocalTime(char* localTime) {
    if (localTime==NULL)
	localTime = (char*) malloc (sizeof(char)*10);

    time_t now = time(NULL);
    struct tm tim = *(localtime(&now));
    return strftime(localTime, 10, "%H:%M:%S", &tim);
}
