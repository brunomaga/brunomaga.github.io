#include <assert.h>
#include <math.h>
#include <cmath>
#include <list>
#include <string.h>
#include <stdlib.h>
#include <limits>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <iosfwd>
#include <iterator>

#include "SerialSlicing.h"

void SerialSlicing::sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, SliceDetails * finalSlicing)
{
    sortTileRecursive(coords, n, mpiComm, NULL, 1, finalSlicing );
}

void SerialSlicing::sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, int * slicingConfiguration, SliceDetails * finalSlicing)
{
    sortTileRecursive(coords, n, mpiComm, slicingConfiguration, 1, finalSlicing);

}

void SerialSlicing::sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, float samplingRate, SliceDetails * finalSlicing)
{
    sortTileRecursive(coords, n, mpiComm, NULL, samplingRate, finalSlicing);
}

void SerialSlicing::sortTileRecursive(
        double *& coords, 
        long long & n, 
        MPI_Comm mpiComm, 
        int * slicingConfiguration,
        float samplingRate,
        SliceDetails * finalSlicing) 
{
    assert(samplingRate<=1 && samplingRate>0);

    int mpiRank=-1, mpiSize=-1;
    MPI_Comm_rank(mpiComm, &mpiRank);
    MPI_Comm_size(mpiComm, &mpiSize);
    
    /*
    if (samplingRate<1)
    {
        Slicing::getSamples(coords_all, n_all, samplingRate, coords, n);
        if (mpiRank==0)
            OutputHandler::show("SBS: Sampling of %.f: from %lld to %lld elements", samplingRate, n_all, n);
    }*/
    
    //gather data from all elements
    int n_int = (int) n;
    long long all_n = 0;
    double *all_coords = NULL;
    int * recvElemsOffset = NULL;
    int * recvElemsCount = mpiRank==0 ? new int[mpiSize] : NULL;
   

    MPI_Gather(&n_int, 1, MPI_INT, recvElemsCount, 1, MPI_INT, 0, mpiComm);
   
    if (mpiRank==0)
    {
      for (int i=0; i<mpiSize; i++)
        all_n += recvElemsCount[i];

      all_coords = new double[all_n*3] ;
      recvElemsOffset = new int [mpiSize] ;

      for (int i=0; i<mpiSize; i++)
      {
        recvElemsCount[i] *=3; //from n to double[3]
        recvElemsOffset[i] = i==0 ? 0 : recvElemsOffset[i-1]+recvElemsCount[i-1];
      }
    }

    MPI_Gatherv(coords, n*3, MPI_DOUBLE, all_coords, recvElemsCount, recvElemsOffset, MPI_DOUBLE, 0, mpiComm);
    SliceDetails universe = Slicing::getUniverseBoundaries(all_coords, all_n, mpiComm);

    if (mpiRank==0)
    {
      /*
      printf("all_n=%lld\n", all_n);
      for (int i=0; i<all_n; i++)
          printf("coords[%d] = [%.2f, %.2f, %.2f]\n",i, all_coords[i*3], all_coords[i*3+1], all_coords[i*3+2]);
      */

      delete [] recvElemsCount; recvElemsCount=NULL;
      delete [] recvElemsOffset; recvElemsOffset=NULL;

      /*
      //get minimum and maximum values in all dimensions in our universe
      OutputHandler::show("Serial: Universe boundaries = [%.2f,%.2f], [%.2f,%.2f], [%.2f,%.2f]",
                universe.min[0], universe.max[0], universe.min[1], universe.max[1], universe.min[2], universe.max[2]);
      */

      //get best slicing configuration, if not user provided slicingConfig = userSlicingConfig;
      int sliceId=0;
      if (slicingConfiguration==NULL)
      {
        int * slicingConfigAuto = new int[3];
        Slicing::calculateBestSlicingCombination (slicingConfigAuto, mpiComm);
        /*
        if (mpiRank==0)
            OutputHandler::show("Serial: Volume will be sub-sliced in %d*%d*%d=%d slices (detected automatically).", slicingConfigAuto[0], slicingConfigAuto[1], slicingConfigAuto[2], mpiSize);
	*/
        sortTileRecursive_aux(0, sliceId, all_coords, all_n, slicingConfigAuto, universe, finalSlicing);
        delete [] slicingConfigAuto; slicingConfigAuto=NULL;
      }
      else
      {
        sortTileRecursive_aux(0, sliceId, all_coords, all_n, slicingConfiguration, universe, finalSlicing);
      }
      delete [] all_coords; all_coords=NULL;
   }
}


void SerialSlicing::sortTileRecursive_aux(int dim, int & sliceId, double * coords, long long n, int * slicingConfiguration, SliceDetails universe, SliceDetails * finalSlicing)
{    
    //recursivity stop condition
    if (dim == 3)
    { 
        if (finalSlicing != NULL)
            memcpy(&finalSlicing[sliceId++], &universe, sizeof(SliceDetails));
        return;
    }

    //sorts neurons in 1 dimension for this subvolume (coordinates and segmentsCount will be updated)
    Slicing::sort_r(coords, n, sizeof (double)*3, (void*) &dim, Slicing::lessOrEqual3D);

    //test slicing
    for (int i=1; i<n; i++)
        if (coords[i*3+dim] < coords[(i-1)*3+dim])
            OutputHandler::Warning("sort_r for dimension %d failed\n", dim);
    
    int slicesCount = slicingConfiguration[dim];    
    double avgElemsPerSlice = (double) n / (double) slicesCount;
 
    //calculate cut points and start recursive approach
    double coordsIterator=0;
    for (int s = 0; s < slicesCount; s++)
    {
        long long startIndex = (long long) coordsIterator;
        coordsIterator += avgElemsPerSlice;
        long long endIndex   = (s==slicesCount-1 ? n : (long long) coordsIterator) -1; //inclusive

        //get coordinates for slice cut
        universe.min[dim] = coords[startIndex*3 + dim];
        universe.max[dim] = coords[endIndex  *3 + dim];

        //BUG FIX: to avoid gaps between slices, we set slice boundaries as midpoints (only useful for shapes with extent)
        //NOT TESTED!!
        //universe.max[dim] = s==slicesCount-1 ? universe.max[dim] : (universe.max[dim]+ coords[(endIndex+1)*3 + dim])/2;
        //universe.min[dim] = s==0             ? universe.min[dim] : (coords[(endIndex-1)*3 + dim] + universe.min[dim])/2;

        int sub_n = endIndex-startIndex+1;
        double * sub_coords = &coords[startIndex*3];
        sortTileRecursive_aux(dim+1, sliceId, sub_coords, sub_n, slicingConfiguration, universe, finalSlicing);
     }    
}
