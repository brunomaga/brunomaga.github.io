#include <assert.h>
#include <math.h>
#include <cmath>
#include <list>
#include <string.h>
#include <stdlib.h>
#include <limits>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <iosfwd>
#include <iterator>

#include "SortBalanceSplit.h"

void SortBalanceSplit::sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, SliceDetails * finalSlicing) 
{
    sortTileRecursive(coords, n, mpiComm, NULL, 1, finalSlicing );
}

void SortBalanceSplit::sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, int * slicingConfiguration, SliceDetails * finalSlicing) 
{
    sortTileRecursive(coords, n, mpiComm, slicingConfiguration, 1, finalSlicing);

}

void SortBalanceSplit::sortTileRecursive(double *& coords, long long & n, MPI_Comm mpiComm, float samplingRate, SliceDetails * finalSlicing) 
{
    sortTileRecursive(coords, n, mpiComm, NULL, samplingRate, finalSlicing);
}

void SortBalanceSplit::sortTileRecursive(
        double *& coords, 
        long long & n, 
        MPI_Comm mpiComm, 
        int * slicingConfiguration,
        float samplingRate,
        SliceDetails * finalSlicing) 
        {

    assert(samplingRate<=1 && samplingRate>0);

    int mpiRank=-1, mpiSize=-1;
    MPI_Comm_rank(mpiComm, &mpiRank);
    MPI_Comm_size(mpiComm, &mpiSize);
    
    /*
    if (samplingRate<1)
    {
        Slicing::getSamples(coords_all, n_all, samplingRate, coords, n);
        if (mpiRank==0)
            OutputHandler::show("SBS: Sampling of %.f: from %lld to %lld elements", samplingRate, n_all, n);
    }*/

    //get minimum and maximum values in all dimensions in our universe
    SliceDetails universe = Slicing::getUniverseBoundaries(coords, n, mpiComm);
    /*
    if (mpiRank==0)
        OutputHandler::show("SBS: Universe boundaries = [%.2f,%.2f], [%.2f,%.2f], [%.2f,%.2f]",
                universe.min[0], universe.max[0], universe.min[1], universe.max[1], universe.min[2], universe.max[2]);
    */
    //get best slicing configuration, if not user provided slicingConfig = userSlicingConfig;    
    if (slicingConfiguration==NULL)
    {
        int * slicingConfigAuto = new int[3];
        Slicing::calculateBestSlicingCombination (slicingConfigAuto, mpiComm);
        /*
        if (mpiRank==0)
            OutputHandler::show("SBS: Volume will be sub-sliced in %d*%d*%d=%d slices (detected automatically).", slicingConfigAuto[0], slicingConfigAuto[1], slicingConfigAuto[2], mpiSize);
        */
        sortTileRecursive_aux(0, 0, coords, n, slicingConfigAuto, universe, MPI_COMM_WORLD, finalSlicing);
        delete [] slicingConfigAuto; slicingConfigAuto=NULL;
    }
    else //user input slicing
    {
        sortTileRecursive_aux(0, 0, coords, n, slicingConfiguration, universe, MPI_COMM_WORLD, finalSlicing);
    }
}

SliceDetails * SortBalanceSplit::getSubSlicesDetails(int dim, int sliceNumber, SliceDetails & universe, int slicesCount, long long myNeuronsCount, double *coordinates, MPI_Comm mpiComm)
{
    //Initialization of variables
    int mpiRank = -1;
    MPI_Comm_rank(mpiComm, &mpiRank);
    
    //return value: the array with all subslices of the universe (parameter)
    SliceDetails * slicesDetails = new SliceDetails[slicesCount];

    double avgCPUsPerSlice = (double) universe.numberOfCPUs / (double) slicesCount;

    if (mpiRank==0 && ceil (avgCPUsPerSlice) != avgCPUsPerSlice) //if is not an integer..
        OutputHandler::Warning("Number of CPUs for slice %d in dimension %d is a floating point number: %f! Please review your slicing algorithm or total number of CPUs.", sliceNumber, dim, avgCPUsPerSlice);

    //populates return data...
    for (int s = 0; s < slicesCount; s++)
    {
        //number of CPUs:
        slicesDetails[s].numberOfCPUs = (int) avgCPUsPerSlice;

        //first and last rank of each slice:
        if (s==0) slicesDetails[s].firstRank=0;
        else slicesDetails[s].firstRank = slicesDetails[s-1].lastRank+1;

        slicesDetails[s].lastRank = ((int) avgCPUsPerSlice) * (s+1) -1;

        //coordinates of all sub slices are same as universe (for other dimensions)
        for (int d = 0; d < 3; d++) 
        {
            if (d==dim) continue;
            slicesDetails[s].min[d] = universe.min[d];
            slicesDetails[s].max[d] = universe.max[d];
        }

        //coordinates of all subSlices for this dimension will be populated
        if (slicesDetails[s].firstRank == mpiRank)
            slicesDetails[s].min[dim] = (double) coordinates[0 + dim];
        if (slicesDetails[s].lastRank == mpiRank)
            slicesDetails[s].max[dim] = (double) coordinates[(myNeuronsCount - 1)*3 + dim];

        MPI_Bcast(&(slicesDetails[s].min[dim]), 1, MPI_DOUBLE, slicesDetails[s].firstRank, mpiComm);
        MPI_Bcast(&(slicesDetails[s].max[dim]), 1, MPI_DOUBLE, slicesDetails[s].lastRank, mpiComm);
    }

    //BUG FIX: to avoid gaps between slices, neighbor ranks will agree on the same slice location at the midpoints
    //(only useful for shapes with extent)
    //NOT TESTED
    /*for (int s=0; s<slicesCount; s++)
    {
        slicesDetails[s].max[dim] = s==slicesCount-1 ? universe.max[dim] : (slicesDetails[s].max[dim]+slicesDetails[s+1].min[dim])/2;
        slicesDetails[s].min[dim] = s==0 ? universe.min[dim] : slicesDetails[s-1].max[dim];
    }*/

    //Validates final data... in case something went wrong before
    if (mpiRank == 0)
        for (int s = 0; s < slicesCount; s++) {

            //checks ranking order within same slice
            if (slicesDetails[s].firstRank > slicesDetails[s].lastRank)
                OutputHandler::Warning("Validation failed for slicing on dim %d: slice %d has first rank %d and last rank %d (FLAG1)",
                    dim, s, slicesDetails[s].firstRank, slicesDetails[s].lastRank);

            //checks spatial ordering
            for (int d = 0; d < 3; d++)
                if (slicesDetails[s].min[d] > slicesDetails[s].max[d])
                    OutputHandler::Warning(
                        "Validation failed for slicing on dim %d: slice %d - ranks %d to %d - was calculated between min %f and max %f for dim %d (FLAG2)",
                        dim, s, slicesDetails[s].firstRank, slicesDetails[s].lastRank, slicesDetails[s].min[d], slicesDetails[s].max[d], d);

            //checks same conditions between neighbooring slices
            if (s == slicesCount - 1) continue;

            if (slicesDetails[s].max[dim] > slicesDetails[s + 1].min[dim])
                OutputHandler::Warning(
                    "Validation failed for slicing on dim %d, slice %d has max %f but next slice %d has min %f (FLAG3)",
                    dim, s, slicesDetails[s].max[dim], s + 1, slicesDetails[s + 1].min[dim]);

            if (slicesDetails[s].lastRank != slicesDetails[s + 1].firstRank-1)
                OutputHandler::Warning("Validation failed for slicing on dim %d: slice %d has last rank %d and slice %d has first rank %d - should be sequential (FLAG4)",
                    dim, s, slicesDetails[s].lastRank, s + 1, slicesDetails[s + 1].firstRank);
        }
    return slicesDetails;
}

void SortBalanceSplit::sortTileRecursive_aux(int dim, int sliceNumber, double *& coords, long long & n, int * slicingConfiguration, SliceDetails & universe, MPI_Comm mpiComm, SliceDetails * finalSlicing)
{    
    //recursivity stop condition: all cpus are now on their only slice,
    //so they will broadcast this info and get the info from all others
    if (dim == 3) 
    {
        if (finalSlicing!=NULL) //if user wants the coordinates of the slices
            MPI_Allgather(&universe, sizeof(SliceDetails), MPI_BYTE,
                finalSlicing, sizeof(SliceDetails), MPI_BYTE,
                MPI_COMM_WORLD);    
        return;
    }

    //sorts neurons in 1 dimension for this subvolume (coordinates and segmentsCount will be updated)
    DistributedSorting::sampleSort(&n, &coords, dim, mpiComm);
    //globalSegmentsCount = DistributedSorting::oddEvenSort(mySegmentsCount, coordinates, dim, mpiComm);
    
    //balances workload so that data will be copied to the CPUs where the respective slice is.
    //Eg: for 8 CPUs, we have 8 slices, therefore:
    //For dim 0: data for slice 0 is in ranks [0..3], for slice 1 in ranks [4..7]
    //For dim 1: slice 0 in [0,1], slice 1 in [2,3], ..., slice 4 in [6.7]
    //For dim 2: slice 0 in [0], slice 1 in [1], ..., slice 7 in [7]
    DistributedLoadBalancing::loadBalancing(&n, &coords, mpiComm);
    
    //populates sliceDetails array which holds the details of every sub-slice (and recursive call)
    SliceDetails * slicesDetails = getSubSlicesDetails(dim, sliceNumber, universe, slicingConfiguration[dim], n, coords, mpiComm);

    //ranks that are not part of this slice, continue...
    int sliceRank, sliceSize, mpiRank;
    MPI_Comm_rank(mpiComm, &sliceRank);
    MPI_Comm_rank(MPI_COMM_WORLD, &mpiRank);
    MPI_Comm_size(mpiComm, &sliceSize);
    /*
    for (int s=0; s<slicingConfiguration[dim]; s++)
    {
      for (int r=0; r<sliceSize; r++)
      {
        MPI_Barrier(mpiComm);
        if (r!=mpiRank) continue;
        printf(
            "\t___S Rank %d (%d): Slice %d: ranks %d-%d :: %.2lf %.2lf, %.2lf %.2lf, %.2lf %.2lf\n", 
            mpiRank, sliceRank, s, slicesDetails[s].firstRank, slicesDetails[s].lastRank,
            slicesDetails[s].min[0], slicesDetails[s].max[0], slicesDetails[s].min[1], 
            slicesDetails[s].max[1], slicesDetails[s].min[2], slicesDetails[s].max[2] );
        }
    }*/
    
    //calls this method recursively for every single sub slice in the next dimension..
    for (int s = 0; s < slicingConfiguration[dim]; s++) {

        if (sliceRank < slicesDetails[s].firstRank || sliceRank > slicesDetails[s].lastRank) continue;

        //splits the actual MPI_Comm in sub MPI_Comms
        MPI_Comm subSliceComm;
        int newRank = sliceRank - slicesDetails[s].firstRank; //[0..N];
        MPI_Comm_split(mpiComm, s /*new group code*/, newRank, &subSliceComm);

        //calls this functions for next dimension, for new sub group, and sub slice
        sortTileRecursive_aux(dim+1, s, coords, n, slicingConfiguration, slicesDetails[s], subSliceComm, finalSlicing);

        MPI_Comm_free(&subSliceComm);
    }    
    delete [] slicesDetails; slicesDetails=NULL;
}
