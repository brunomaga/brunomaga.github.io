# Simulator of Leaky Integrate-And-Fire Neuron Models on a Brunel Network

## About

A Simulation of Leaky Integrate-and-Fire Neuron models with the Brunel Network activity defined by intra-network or extra-network currents (Event);

## Code Structure 

![alt text](doc/diagram/diagramme.png "Diagramme cmake")

## External Documentation

- The Brunel Model: *Dynamics of Sparsely Connected Networks of Excitatory
and Inhibitory Spiking Neurons, Brunel et al* [pdf](https://web.stanford.edu/group/brainsinsilicon/documents/BrunelSparselyConnectedNets.pdf)
- An example of Brunel Network in Python ( [here](http://arken.nmbu.no//~plesser/publications/Gewa_2012_533_preprint.pdf) )

## Manual

To execute the default application, run
```
./simulator
```

To change the type of simulation, enter
```
.//simulator -m 0 	for AnalyticFixedStep
		1 	for Explicit
		2 	for Implicit
		3 	for AnalyticVariableStep
```
	
For help and parameters, enter
```
    ./simulator --help
``` 

### Contributors

- Bruno Magalhaes <bruno.magalhaes@epfl.ch>
- Leo Sumi <leo.sumi@epfl.ch>
- Thais Lindemann <thais.lindemann@epfl.ch> 
- Johannes Brune <johannes.brune@epfl.ch>
- Laure Font <laure.font@epfl.ch> 
- Laurine Kolly <laurine.kolly@epfl.ch>
- Gael Reganha <gael.reganha@epfl.ch>
- Violette Zanotti <violette.zanotti@epfl.ch>
- Julie Brancato <julie.brancato@epfl.ch>
- Fiona Joseph <fiona.joseph@epfl.ch>
- Clara David-Vaudey <clara.david-vaudey@epfl.ch> 

